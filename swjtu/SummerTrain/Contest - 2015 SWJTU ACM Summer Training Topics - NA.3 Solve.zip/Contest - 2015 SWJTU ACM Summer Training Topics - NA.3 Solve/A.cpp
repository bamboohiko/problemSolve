#include <iostream>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
int  tab[1005];

int main() {
    int T; scanf("%d", &T);
    bool flag = 0;
    while(T--) {
        flag = 0;
        
        int n; scanf("%d", &n);

        for(int i = 0 ; i < n; i++) {
            scanf("%d", &tab[i]);
        }

        sort(tab, tab + n);
        for(int i = n - 1 ; i >= 0; i--) {
            for (int j = i - 1; j >= 0; j--) {
                if(binary_search(tab, tab + n, tab[i] - tab[j])) {
                    printf("%d\n", tab[i] );
                    flag = 1;
                    break;
                }
            }
            if(flag) break;
        }
        if(!flag) printf("%d\n", 0);
    }
    return 0;
}