#include<iostream>
#include<cmath>
#include<stdio.h>
#include<cstring>
using namespace std;
double a[100][100];
int main()
{
          int i,j,k,m,n,r;double p,q,f,g;
        //  freopen("data1.in","r",stdin);
          //  freopen("data.out","w",stdout);
           while(cin>>n)
           {
                      if(n==0)break;
              memset(a,0,sizeof(a));m=1;
               for(i=0;i<n;i++)for(j=0;j<n;j++)cin>>a[i][j];
               for(i=0;i<n;i++)
               {
                 r=i;
                  for(j=i+1;j<n;j++)if(fabs(a[j][i])>fabs(a[r][i]))r=j;
                  if(r!=i){for(j=0;j<n;j++)swap(a[i][j],a[r][j]);m=-m;}
                   for(k=i+1;k<n;k++)
                   {
                      f=a[k][i]/a[i][i];
                       for(j=0;j<n;j++)a[k][j]-=f*a[i][j];
                   }
               }
               g=1;
                for(i=0;i<n;i++)g*=a[i][i];
                printf("%.0lf\n",g*m);
           }

           return 0;
}