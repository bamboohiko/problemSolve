#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

typedef long long Lint;

typedef struct _point{
	Lint  x, y;
}Point;

#define  Less(a, b)  ( a.y < b.y || a.y == b.y && a.x < b.x )
#define  Equal(a, b) ( a.x == b.x && a.y == b.y )
#define  Mul(p, a, b) ( (a.x-p.x)*(b.y-p.y) - (a.y-p.y)*(b.x-p.x) )

void Qsort(Point *a, int s, int e){
	Point  x, tmp;
	int  i = s+rand()%(e-s+1), j = e-1;
	x = a[i]; a[i] = a[e]; a[e] = x;
	i = s;
	while(i <= j){
		while(s <= j && Less(x, a[j]) ) --j;
		while(i < e && Less(a[i], x) ) ++i;
		if( i <= j ){
			tmp = a[i]; a[i] = a[j]; a[j] = tmp;
			++i; --j;
		}
	}
	a[e] = a[i]; a[i] = x;
	if( s < i-1 )  Qsort(a, s, i-1);
	if( i+1 < e ) Qsort(a, i+1, e);
}


#define  MaxN (100004)

Point  src[MaxN], p[MaxN];
int  size;
char  flag[MaxN];
int  ID[MaxN];

int GranHam(Point *a, int size_a, Point *p){
	int  i, j, size_p = 0;
	if( size_a < 3 ) return 0;
	Qsort(a, 0, size_a-1);
	for(j = 0,i = 1; i < size_a; ++i){
		if( Equal(a[j], a[i]) ) continue;
		a[++j] = a[i];
	}
	size_a = j+1;
	if( size_a < 3 ) return 0;
	memset(flag, 0,size_a);
	flag[1] = 1;  ID[0] = 0; ID[1] = 1;
	p[0] = a[0];  p[1] = a[1]; size_p = 1;
	for(i = 2; i < size_a; ++i){
		while(size_p && Mul(p[size_p-1], p[size_p], a[i]) < 0) flag[ID[size_p--]] = 0;
		p[++size_p] = a[i];  flag[i] = 1;  ID[size_p] = i;
	}
	for(i = size_a-1; i >= 0; --i){
		if(flag[i]) continue;
		while(size_p && Mul(p[size_p-1], p[size_p], a[i]) < 0) flag[ID[size_p--]] = 0;
		p[++size_p] = a[i];  flag[i] = 1;  ID[size_p] = i;
	}
	return  size_p;
}

int main(){
	int  i, tt;
	double  area;
	scanf("%d", &tt);
	while( tt-- ){
		scanf("%d", &size);
		for(i = 0; i < size; ++i) scanf("%I64d%I64d", &src[i].x, &src[i].y);
		area = 0.0;
		size = GranHam(src, size, p);
		p[size] = p[0];
		for(i = 0; i < size; ++i){
			area += 1.0*p[i].x*p[i+1].y - p[i].y*p[i+1].x;
		}
		printf("%.1lf\n", area < 0.0 ? -area/2.0 : area/2.0);
	}
	return 0;
}