#include <iostream>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <cstdio>
using namespace std;

long long a[31];
void init(){
	long long t=1;
	for(int i=0;i<31;i++){
		a[i]=t;
		t*=2;
	}
}
int find_num(long long x){
	for(int i=0;i<31;i++){
		if(x<a[i]){
			return i;
		}else if(x==a[i])
			return -1;
	}
	return 32;
}
int cal(long long n,long long k){
	int x = find_num(n);
	long long t;
	if(x == -1)
		return 1;
	else{
		t = n - a[x - 1];
		if(k <= t){
			cal(t,k);
		} else if(k>a[x-1]){
			cal(t,n-k+1);
		} else
			return 0;
	}
}
int main() {
	int t;
	long long n, k;
	scanf("%d", &t);
	init();
	while(t--){
		scanf("%I64d%I64d",&n,&k);
		if( cal(n + 1, k + 1)) {
			printf("Odd\n");
		}else printf("Even\n");
	}
	return 0;
}