#include<iostream>
#include<cstdio>
#include<cmath>
#define PI 3.141592653589793
using namespace std;
double trianglearea(double a,double b,double c)
{double p=(a+b+c)/2;
return sqrt(p*(p-a)*(p-b)*(p-c));
}
int main()
{double RA,RB,r;double TA,TB,ZA,ZB;double VA,VB,V;
while(scanf("%lf%lf",&RA,&RB)!=EOF)
{	r=trianglearea(RA,RA,RB)*2/RA;
	TB=2*PI*(1-sqrt(RB*RB-r*r)/RB)*RB*RB*RB/3;
	ZB=r*r*PI*sqrt(RB*RB-r*r)/3;
	TA=2*PI*(1-sqrt(RA*RA-r*r)/RA)*RA*RA*RA/3;
	ZA=r*r*PI*sqrt(RA*RA-r*r)/3;
	VA=TA-ZA;
	VB=TB-ZB;
	V=VB+VA;
	printf("%.5lf\n",V);
}
return 0;
}