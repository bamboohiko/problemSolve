import java.io.*;
import java.math.*;
import java.util.*;


public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int l = in.nextInt(), cnt = 1;
		BigInteger a, b;
		while(l-- > 0) {
			a = in.nextBigInteger();
			b = in.nextBigInteger();
			System.out.print("Test #"+ cnt + ": ");
			++ cnt;
			if (a.compareTo(b) == 0) {
				System.out.println("=");
			} else if (a.compareTo(b) > 0) {
				System.out.println(">");
			} else {
				System.out.println("<");
			}
		}
	}
}