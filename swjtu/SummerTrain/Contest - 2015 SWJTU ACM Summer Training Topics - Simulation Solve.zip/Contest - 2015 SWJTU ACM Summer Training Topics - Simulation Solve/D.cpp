#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;

vector<string> s;

int main () {
    //freopen("in.txt", "r", stdin);
    string op, now, URL;
    int T, cur, cnt = 1; cin >> T;
    while (T --) {
        s.clear(); s.push_back("http://www.acm.org/");
        cur = 0;
        printf("Test #%d:\n", cnt++);
        while (cin >> op) {
            if (op == "VISIT") {
                cin >> URL; cout << URL << endl;
                while (s.size() - 1 > cur) {
                    s.pop_back();
                }
                s.push_back(URL); cur ++;
            } else if (op == "BACK") {
                cur --;
                if (cur < 0) {
                    cout << "Ignored" << endl;
                    cur = 0;
                    continue;
                }
                cout << s[cur] << endl;
            } else if (op == "FORWARD") {
                cur ++;
                if (cur >= s.size()) {
                    cout << "Ignored" << endl;
                    cur = s.size() - 1;
                    continue;
                }
                cout << s[cur] << endl;
            } else if (op == "QUIT") {
                break;
            }
        }
    }
    return 0;
}