import java.io.*;
import java.math.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String sDt = "08:02:00 4/20/2013";
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss MM/dd/yyyy");
		int cnt = 1;
		//System.out.println(cal.getTime());
		int t = in.nextInt();
		while (t-- > 0) {
			Calendar cal=Calendar.getInstance();
			cal.set(Calendar.YEAR, 2013);
			cal.set(Calendar.MONTH, 3);
			cal.set(Calendar.DAY_OF_MONTH, 20);
			cal.set(Calendar.HOUR_OF_DAY, 8);
			cal.set(Calendar.MINUTE, 02);
			cal.set(Calendar.SECOND, 00);
			int a = in.nextInt();
			Calendar ans = cal;
			ans.add(Calendar.SECOND, a);
			Date date = ans.getTime();
	        DateFormat format1 = new SimpleDateFormat("M/d/yyyy");  
	        DateFormat format2 = new SimpleDateFormat("HH:mm:ss"); 
	        System.out.print("Case #" + cnt + ": ");cnt++; 
			System.out.print(format2.format(date) + " ");
			System.out.println(format1.format(date));
		}
	}
}