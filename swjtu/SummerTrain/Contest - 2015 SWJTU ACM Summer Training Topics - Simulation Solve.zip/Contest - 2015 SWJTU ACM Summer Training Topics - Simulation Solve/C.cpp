#include"iostream"
#include"cstdio"
#include"string"
#include<string.h>
using namespace std;
void chuli(char *a){
    char s[104];
	int i,j=0,reg=0;

	for(i=0;i<strlen(a);i++){
	  
		if(a[i]=='-'){
		   s[j++]='-';
		 }
		if(a[i]=='0'&&reg==1){
		   s[j++]='0';
		   
		}
		 if(a[i]=='+'){}
		 if(a[i]>='1'&&a[i]<='9')
		 {s[j++]=a[i];reg=1;}
		
	}
	
	s[j]='\0';
//	cout<<"s:"<<s<<endl;

	if((strlen(s)==1&&s[0]=='-')||strlen(s)==0)
	{a[0]='0';a[1]='\0';}
	else{
//	cout<<"s"<<s<<endl;
	for(i=0;i<strlen(s);i++)
		a[i]=s[i];
	a[i]='\0';}
//	cout<<a<<endl;
}
char comp(char *a,char *b){
	if(a[0]=='-'){
	  if(b[0]!='-')
	     return '<';
	  else 
	  {
	    if(strlen(a)>strlen(b))
          return '<';
		else if(strlen(a)<strlen(b))
			return '>';
		else {
			if(strcmp(a,b)>0)
		         return '<';
			else if(strcmp(a,b)<0)
				return '>';
			else 
				return '=';
		}
	  }
	}
	else {
	  if(b[0]=='-')
	       return '>';
	 else
	 {
		 if(strlen(a)>strlen(b))
          return '>';
		else if(strlen(a)<strlen(b))
			return '<';
		else {
			if(strcmp(a,b)>0)
		         return '>';
			else if(strcmp(a,b)<0)
				return '<';
			else 
				return '=';
		}
	}
 
}

}
int main(){
  int T,i=0;
  char ans;
  char a[104],b[104];
  cin>>T;
  while(i++<T){
    cin>>a>>b;
   chuli(a);
	chuli(b);

    ans=comp(a,b);

	cout<<"Test #"<<i<<": "<<ans<<endl;
  }
  return 0;
}